Some background reading:

Generic Sensor Format Specification
http://www.ldeo.columbia.edu/res/pi/MB-System/formatdoc/gsf_spec.pdf

Unified Transportation Sensor Data Format (UTSDF): Introduction 
http://www.d.umn.edu/~tkwon/TDRLSoftware/UTSDF_Intro.pdf